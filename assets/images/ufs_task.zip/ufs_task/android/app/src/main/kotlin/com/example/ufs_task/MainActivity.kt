package com.example.ufs_task

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
